Fichier t�l�charg� sur http://cmap.comersis.com

Vous pouvez utiliser les cartes vectorielles CMAP
librement sur internet tant que notre logo reste 
visible.
Ce logo nous permet de continuer � proposer des 
cartes gratuites. Il est le principe m�me de 
Comersis.

Nous remercions par avance celles et ceux qui 
ferons un lien vers notre site : 

http://cmap.comersis.com



*****************************************************************
Si vous souhaitez t�l�charger les fichiers sources de ces cartes,
rendez-vous sur http://cmap.comersis.com

*****************************************************************

Pour toute information : 

info@comersis.com

